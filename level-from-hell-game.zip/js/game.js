
document.addEventListener("DOMContentLoaded", () => {
    const canvas = document.getElementById("gameCanvas");
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "red";
    ctx.fillRect(100, 100, 100, 100);
    ctx.fillStyle = "white";
    ctx.font = "20px Arial";
    ctx.fillText("Level 1 - Hell Begins", 120, 90);
});
